﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Description;
using Microsoft.Xrm.Sdk.Client;
using System.IO;
using System.Xml;
using Microsoft.Xrm.Sdk.Messages;
using Microsoft.Xrm.Sdk;
using Microsoft.Xrm.Sdk.Query;
using Microsoft.Crm.Sdk.Messages;
using Microsoft.Xrm.Sdk.Metadata;
namespace EntitySecurityRole
{
    public static class Helper
    {
        #region variable used
        private static List<privilegeSet> _privilage;

        internal static List<privilegeSet> Privilage
        {
            get { return Helper._privilage; }
            set { Helper._privilage = value; }
        }

        private static List<Entity> _entPrivileges;

        public static List<Entity> EntPrivileges
        {
            get { return Helper._entPrivileges; }
            set { Helper._entPrivileges = value; }
        }

        private static List<MyEntity> _myEntities;

        internal static List<MyEntity> MyEntities
        {
            get { return Helper._myEntities; }
            set { Helper._myEntities = value; }
        }
        private static List<systemUser> _systemUser;
        internal static List<systemUser> SystemUser
        {
            get { return Helper._systemUser; }
            set { Helper._systemUser = value; }
        }
        private static List<systemUser> _systemUsergrid;
        internal static List<systemUser> SystemUsergrid
        {
            get { return Helper._systemUsergrid; }
            set { Helper._systemUsergrid = value; }
        }
        private static List<SecurityRole> _securityRoles;
        internal static List<SecurityRole> SecurityRoles
        {
            get { return Helper._securityRoles; }
            set { Helper._securityRoles = value; }
        }
        private static List<Team> _teams;
        internal static List<Team> Teams
        {
            get { return Helper._teams; }
            set { Helper._teams = value; }
        }
        private static List<Queue> _queues;

        public static List<Queue> Queues
        {
            get { return Helper._queues; }
            set { Helper._queues = value; }
        }

        private static OrganizationServiceProxy _serviceProxy;
        public static OrganizationServiceProxy ServiceProxy
        {
            get { return Helper._serviceProxy; }
            set { Helper._serviceProxy = value; }
        }
        private static string _OrganizationUri;
        public static string OrganizationUri
        {
            get { return Helper._OrganizationUri; }
            set { Helper._OrganizationUri = value; }
        }
        private static ClientCredentials _Credentials = null;
        public static ClientCredentials Credentials
        {
            get { return Helper._Credentials; }
            set { Helper._Credentials = value; }
        }

        #endregion

        internal static void createConn(IOrganizationService Service)
        {

            _serviceProxy = (OrganizationServiceProxy)Service;

        }
        internal static List<systemUser> getUserbySecurityRole(string SecurityRole, string buName)
        {

            SystemUser = new List<systemUser>();
            SystemUsergrid = new List<systemUser>();
            int fetchCount = 5000;// Initialize the page number.
            int pageNumber = 1;// Initialize the number of records.
            string pagingCookie = null;
            string fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false' >" +
"  <entity name='systemuser' >" +
"    <attribute name='fullname' />" +
"    <attribute name='businessunitid' />" +
"    <attribute name='domainname' />" +
"    <attribute name='systemuserid' />" +
"    <order attribute='fullname' descending='false' />" +
"    <filter type='and' >" +
"      <condition attribute='isdisabled' operator='eq' value='0' />" +
"      <condition attribute='accessmode' operator='ne' value='3' />" +
"    </filter>" +
" <link-entity name='systemuserroles' from='systemuserid' to='systemuserid' visible='false' intersect='true'>" +
"      <link-entity name='role' from='roleid' to='roleid' alias='ab'>" +
"        <filter type='and'>" +
   "<condition attribute='name' operator='eq'  value='" + SecurityRole + "' />" +
"        </filter>" +
"      </link-entity>" +
"    </link-entity>" +
"   <link-entity name='businessunit' from='businessunitid' to='businessunitid' alias='ah'>" +
"      <filter type='and'>" +
"        <condition attribute='name' operator='eq' value='" + buName + "' />" +
"      </filter>" +
"    </link-entity>" +

"  </entity>" +
"</fetch>";


            while (true)
            {
                // Build fetchXml string with the placeholders.
                string xml = CreateXml(fetchXML, pagingCookie, pageNumber, fetchCount);

                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                EntityCollection returnCollection = ((RetrieveMultipleResponse)_serviceProxy.Execute(fetchRequest1)).EntityCollection;

                foreach (Entity ent in returnCollection.Entities)
                {
                    systemUser user = new systemUser();
                    user.Domainname = ent.Attributes["domainname"].ToString();
                    user.FullName = ent.Attributes["fullname"].ToString();
                    user.BusinessUnit = ((EntityReference)ent.Attributes["businessunitid"]).Name;
                    user.SystemUserID = ent.Id;
                    SystemUser.Add(user);
                    SystemUsergrid.Add(user);
                }

                // Check for morerecords, if it returns 1.
                if (returnCollection.MoreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    pageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    // If no more records in the result nodes, exit the loop.
                    break;
                }
            }


            return SystemUser;
        }
        internal static List<MyEntity> getEntities()
        {
            MyEntities = new List<MyEntity>();
            RetrieveAllEntitiesResponse retrieveAllEntitiesResponse = (RetrieveAllEntitiesResponse)_serviceProxy.Execute(new RetrieveAllEntitiesRequest());
            EntityMetadata[] entityMetadata = retrieveAllEntitiesResponse.EntityMetadata;
          
            foreach (EntityMetadata current in entityMetadata)
            {
                string text = (current.DisplayName != null && current.DisplayName.UserLocalizedLabel != null) ? current.DisplayName.UserLocalizedLabel.Label : "N/A";
                bool flag2 = text != "N/A";
                if (flag2)
                {
                    MyEntity ent = new MyEntity();
                    ent.DisplayName = text;
                    ent.EntityId = (Guid)current.MetadataId;
                    ent.LogicalName = current.LogicalName;
                    ent.SchemaName = current.SchemaName;
                    MyEntities.Add(ent);
                }
            }



            return MyEntities;
        }
        internal static string CreateXml(string xml, string cookie, int page, int count)
        {
            StringReader stringReader = new StringReader(xml);
            XmlTextReader reader = new XmlTextReader(stringReader);

            // Load document
            XmlDocument doc = new XmlDocument();
            doc.Load(reader);

            return CreateXml(doc, cookie, page, count);
        }
        internal static string CreateXml(XmlDocument doc, string cookie, int page, int count)
        {
            XmlAttributeCollection attrs = doc.DocumentElement.Attributes;

            if (cookie != null)
            {
                XmlAttribute pagingAttr = doc.CreateAttribute("paging-cookie");
                pagingAttr.Value = cookie;
                attrs.Append(pagingAttr);
            }

            XmlAttribute pageAttr = doc.CreateAttribute("page");
            pageAttr.Value = System.Convert.ToString(page);
            attrs.Append(pageAttr);

            XmlAttribute countAttr = doc.CreateAttribute("count");
            countAttr.Value = System.Convert.ToString(count);
            attrs.Append(countAttr);

            StringBuilder sb = new StringBuilder(1024);
            StringWriter stringWriter = new StringWriter(sb);

            XmlTextWriter writer = new XmlTextWriter(stringWriter);
            doc.WriteTo(writer);
            writer.Close();

            return sb.ToString();
        }
        internal static List<SecurityRole> getSecurityRole()
        {
            EntityCollection returnCollection;
            List<SecurityRole> accessRoles = new List<SecurityRole>();
            int fetchCount = 5000;// Initialize the page number.
            int pageNumber = 1;// Initialize the number of records.
            string pagingCookie = null;
            string fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>"
  + "<entity name='role'>"
    + "<attribute name='name' />"
    + "<attribute name='businessunitid' />"
    + "<attribute name='roleid' />"
    + "<order attribute='name' descending='false' />"
        + "<filter type='and'>"
          + "<condition attribute='businessunitid' operator='eq-businessid'  />"
        + "</filter>"
  + "</entity>"
+ "</fetch>";
            while (true)
            {
                // Build fetchXml string with the placeholders.
                string xml = CreateXml(fetchXML, pagingCookie, pageNumber, fetchCount);

                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                returnCollection = ((RetrieveMultipleResponse)_serviceProxy.Execute(fetchRequest1)).EntityCollection;
                foreach (Entity ent in returnCollection.Entities)
                {
                    SecurityRole SecurityRole = new SecurityRole();

                    SecurityRole.Name = ent.Attributes["name"].ToString();
                    SecurityRole.BusinessUnit = (EntityReference)ent.Attributes["businessunitid"];
                    SecurityRole.RoldId = ent.Id;
                    accessRoles.Add(SecurityRole);
                }

                // Check for morerecords, if it returns 1.
                if (returnCollection.MoreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    pageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    // If no more records in the result nodes, exit the loop.
                    break;
                }
            }


            return accessRoles;
        }
        internal static List<MyBusinessUnit> getBUs()
        {
            EntityCollection returnCollection;
            List<MyBusinessUnit> Bulist = new List<MyBusinessUnit>();
            int fetchCount = 5000;// Initialize the page number.
            int pageNumber = 1;// Initialize the number of records.
            string pagingCookie = null;
            string fetchXML = "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='false'>" +
"  <entity name='businessunit'>" +
"    <attribute name='name' />" +
"    <attribute name='parentbusinessunitid' />" +
"    <attribute name='businessunitid' />" +
"    <order attribute='name' descending='false' />" +
"  </entity>" +
"</fetch>"; ;
            while (true)
            {
                // Build fetchXml string with the placeholders.
                string xml = CreateXml(fetchXML, pagingCookie, pageNumber, fetchCount);

                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                returnCollection = ((RetrieveMultipleResponse)_serviceProxy.Execute(fetchRequest1)).EntityCollection;
                foreach (Entity ent in returnCollection.Entities)
                {
                    MyBusinessUnit Bu = new MyBusinessUnit();

                    Bu.DisplayName = ent.Attributes["name"].ToString();
                    Bu.BuID = ent.Id;
                    Bulist.Add(Bu);
                }

                // Check for morerecords, if it returns 1.
                if (returnCollection.MoreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    pageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    // If no more records in the result nodes, exit the loop.
                    break;
                }
            }


            return Bulist;
        }
        internal static List<Team> getTeambySecurityRole(string SecurityRole, string buName)
        {
            List<Team> userTeams = new List<Team>();
            int fetchCount = 5000;// Initialize the page number.
            int pageNumber = 1;// Initialize the number of records.
            string pagingCookie = null;
            string fetchXML =
                "<fetch version='1.0' output-format='xml-platform' mapping='logical' distinct='true'>"
  + "<entity name='team'>"
    + "<attribute name='name' />"
    + "<attribute name='businessunitid' />"
    + "<attribute name='teamid' />"
    + "<attribute name='teamtype' />"
     + "<filter>"
      + "<condition attribute='name' operator='neq' value='" + buName + "' />"
    + "</filter>"
    + "<order attribute='name' descending='false' />"


    + "<link-entity name='teamroles' from='teamid' to='teamid' visible='false' intersect='true'>"
      + "<link-entity name='role' from='roleid' to='roleid' alias='ac'>"
        + "<filter type='and'>"
           + "<condition attribute='name' operator='eq'  value='" + SecurityRole + "' />"
        + "</filter>"
      + "</link-entity>"
    + "</link-entity>"


  + "</entity>"
+ "</fetch>";
            while (true)
            {
                // Build fetchXml string with the placeholders.
                string xml = CreateXml(fetchXML, pagingCookie, pageNumber, fetchCount);

                // Excute the fetch query and get the xml result.
                RetrieveMultipleRequest fetchRequest1 = new RetrieveMultipleRequest
                {
                    Query = new FetchExpression(xml)
                };

                EntityCollection returnCollection = ((RetrieveMultipleResponse)_serviceProxy.Execute(fetchRequest1)).EntityCollection;
                foreach (Entity ent in returnCollection.Entities)
                {
                    Team team = new Team();
                    team.Name = ent.Attributes["name"].ToString();
                    team.BusinessUnit = (EntityReference)ent.Attributes["businessunitid"];
                    team.TeamId = ent.Id;
                    userTeams.Add(team);
                }

                // Check for morerecords, if it returns 1.
                if (returnCollection.MoreRecords)
                {
                    // Increment the page number to retrieve the next page.
                    pageNumber++;
                    // Set the paging cookie to the paging cookie returned from current results.                            
                    pagingCookie = returnCollection.PagingCookie;
                }
                else
                {
                    // If no more records in the result nodes, exit the loop.
                    break;
                }
            }


            return userTeams;
        }
        internal static void RolePrivileges(MyEntity entity)
        {
            string entName = string.Empty;

            if (entity.IsActivity)
            {
                entName = "Activity";
            }
            else if (entity.SchemaName.ToLower() == "annotation")
            {
                entName = "Note";
            }
            else if (entity.SchemaName.ToLower() == "ActivityPointer")
            {
                entName = "Activity";
            }
            else if (entity.SchemaName.ToLower() == "systemuser")
            {
                entName = "User";
            }

            else
            {
                entName = entity.SchemaName.ToLower();
            }

            QueryExpression privilegeQuery = new QueryExpression { EntityName = "privilege", ColumnSet = new ColumnSet(true) };
            var filter = new FilterExpression(LogicalOperator.Or);
            filter.AddCondition("name", ConditionOperator.Like, "prvRead" + entName);
            filter.AddCondition("name", ConditionOperator.Like, "prvWrite" + entName);
            filter.AddCondition("name", ConditionOperator.Like, "prvAppend" + entName);
            filter.AddCondition("name", ConditionOperator.Like, "prvAppendTo" + entName);
            filter.AddCondition("name", ConditionOperator.Like, "prvCreate" + entName);
            filter.AddCondition("name", ConditionOperator.Like, "prvDelete" + entName);
            filter.AddCondition("name", ConditionOperator.Like, "prvShare" + entName);
            filter.AddCondition("name", ConditionOperator.Like, "prvAssign" + entName);

            privilegeQuery.Criteria = filter;
            var privileges = _serviceProxy.RetrieveMultiple(privilegeQuery);
            Privilage = new List<privilegeSet>();
            if (privileges.Entities.Count() == 0)
            {
                System.Windows.Forms.MessageBox.Show("No Role found for " + entity.SchemaName);
            }
            else
                foreach (SecurityRole role in SecurityRoles)
                {
                    privilegeSet pri = new privilegeSet(role.Name);
                    RetrieveRolePrivilegesRoleRequest RolePrivilegesRequest = new RetrieveRolePrivilegesRoleRequest();
                    RolePrivilegesRequest.RoleId = role.RoldId;
                    RetrieveRolePrivilegesRoleResponse roleResponse = (RetrieveRolePrivilegesRoleResponse)_serviceProxy.Execute(RolePrivilegesRequest);
                    foreach (Entity ent in privileges.Entities)
                    {
                        var p = roleResponse.RolePrivileges.Where(x => x.PrivilegeId.Equals(ent.Id)).ToList<RolePrivilege>();
                        if (p.Count() > 0)
                        {
                            switch (p[0].Depth.ToString())
                            {
                                case "Global":
                                    {
                                        if (ent.Attributes["name"].ToString().Contains("prvRead"))
                                        {
                                            pri.Read = Properties.Resources.organization;
                                            pri.Read.Tag = "Organization";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvWrite"))
                                        {
                                            pri.Write = Properties.Resources.organization;
                                            pri.Write.Tag = "Organization";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvAppendTo"))
                                        {
                                            pri.AppendTo = Properties.Resources.organization;
                                            pri.AppendTo.Tag = "Organization";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvAppend"))
                                        {
                                            pri.Append = Properties.Resources.organization;
                                            pri.Append.Tag = "Organization";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvCreate"))
                                        {
                                            pri.Create = Properties.Resources.organization;
                                            pri.Create.Tag = "Organization";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvDelete"))
                                        {
                                            pri.Delete = Properties.Resources.organization;
                                            pri.Delete.Tag = "Organization";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvShare"))
                                        {
                                            pri.Share = Properties.Resources.organization;
                                            pri.Share.Tag = "Organization";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvAssign"))
                                        {
                                            pri.Assign = Properties.Resources.organization;
                                            pri.Assign.Tag = "Organization";
                                        }

                                        break;
                                    }
                                case "Deep":
                                    {
                                        if (ent.Attributes["name"].ToString().Contains("prvRead"))
                                        {
                                            pri.Read = Properties.Resources.P_BU;
                                            pri.Read.Tag = "Parent: Child Business Units";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvWrite"))
                                        {
                                            pri.Write = Properties.Resources.P_BU;
                                            pri.Write.Tag = "Parent: Child Business Units";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvAppendTo"))
                                        {
                                            pri.AppendTo = Properties.Resources.P_BU;
                                            pri.AppendTo.Tag = "Parent: Child Business Units";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvAppend"))
                                        {
                                            pri.Append = Properties.Resources.P_BU;
                                            pri.Append.Tag = "Parent: Child Business Units";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvCreate"))
                                        {
                                            pri.Create = Properties.Resources.P_BU;
                                            pri.Create.Tag = "Parent: Child Business Units";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvDelete"))
                                        {
                                            pri.Delete = Properties.Resources.P_BU;
                                            pri.Delete.Tag = "Parent: Child Business Units";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvShare"))
                                        {
                                            pri.Share = Properties.Resources.P_BU;
                                            pri.Share.Tag = "Parent: Child Business Units";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvAssign"))
                                        {
                                            pri.Assign = Properties.Resources.P_BU;
                                            pri.Assign.Tag = "Parent: Child Business Units";
                                        }

                                        break;
                                    }
                                case "Local":
                                    {
                                        if (ent.Attributes["name"].ToString().Contains("prvRead"))
                                        {
                                            pri.Read = Properties.Resources.BU;
                                            pri.Read.Tag = "Business Unit";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvWrite"))
                                        {
                                            pri.Write = Properties.Resources.BU;
                                            pri.Write.Tag = "Business Unit";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvAppendTo"))
                                        {
                                            pri.AppendTo = Properties.Resources.BU;
                                            pri.AppendTo.Tag = "Business Unit";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvAppend"))
                                        {
                                            pri.Append = Properties.Resources.BU;
                                            pri.Append.Tag = "Business Unit";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvCreate"))
                                        {
                                            pri.Create = Properties.Resources.BU;
                                            pri.Create.Tag = "Business Unit";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvDelete"))
                                        {
                                            pri.Delete = Properties.Resources.BU;
                                            pri.Delete.Tag = "Business Unit";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvShare"))
                                        {
                                            pri.Share = Properties.Resources.BU;
                                            pri.Share.Tag = "Business Unit";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvAssign"))
                                        {
                                            pri.Assign = Properties.Resources.BU;
                                            pri.Assign.Tag = "Business Unit";
                                        }

                                        break;
                                    }
                                case "Basic":
                                    {
                                        if (ent.Attributes["name"].ToString().Contains("prvRead"))
                                        {
                                            pri.Read = Properties.Resources.user;
                                            pri.Read.Tag = "User";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvWrite"))
                                        {
                                            pri.Write = Properties.Resources.user;
                                            pri.Write.Tag = "User";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvAppendTo"))
                                        {
                                            pri.AppendTo = Properties.Resources.user;
                                            pri.AppendTo.Tag = "User";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvAppend"))
                                        {
                                            pri.Append = Properties.Resources.user;
                                            pri.Append.Tag = "User";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvCreate"))
                                        {
                                            pri.Create = Properties.Resources.user;
                                            pri.Create.Tag = "User";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvDelete"))
                                        {
                                            pri.Delete = Properties.Resources.user;
                                            pri.Delete.Tag = "User";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvShare"))
                                        {
                                            pri.Share = Properties.Resources.user;
                                            pri.Share.Tag = "User";
                                        }
                                        else if (ent.Attributes["name"].ToString().Contains("prvAssign"))
                                        {
                                            pri.Assign = Properties.Resources.user;
                                            pri.Assign.Tag = "User";
                                        }

                                        break;
                                    }


                            }

                        }

                    }

                    Privilage.Add(pri);

                }






        }

    }
}
