﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EntitySecurityRole
{
    internal class MyBusinessUnit
    {
        private string _displayName;

        public string DisplayName
        {
            get { return _displayName; }
            set { _displayName = value; }
        }
        private Guid _buID;

        public Guid BuID
        {
            get { return _buID; }
            set { _buID = value; }
        }

      
    }
}
