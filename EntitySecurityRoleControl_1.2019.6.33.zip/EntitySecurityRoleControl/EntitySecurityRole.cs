﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using XrmToolBox.Extensibility;
namespace EntitySecurityRole
{
    public partial class EntitySecurityRole : PluginControlBase
    {
        public EntitySecurityRole()
        {
            InitializeComponent();
        }

        private void btn_retEntity_Click(object sender, EventArgs e)
        {
            if (base.Service != null)
            {
                Helper.createConn(((Microsoft.Xrm.Tooling.Connector.CrmServiceClient)base.Service).OrganizationServiceProxy);
                WorkAsync(new WorkAsyncInfo
           {
               Message = "Retrieveing entities and security roles...",
               Work = (bw, m) =>
               {

                   //Set entity drop down
                   
                   drp_entities.DataSource = null;
                   drp_entities.Items.Clear();
                   List<MyEntity> MyEntitys = Helper.getEntities();
                   MyEntitys.Sort((p, q) => p.DisplayName.CompareTo(q.DisplayName));
                   MyEntity Select = new MyEntity();
                   Select.DisplayName = "--Select--";
                   Select.EntityId = Guid.Empty;
                   MyEntitys.Insert(0, Select);
                   drp_entities.DataSource = MyEntitys;
                   drp_entities.DisplayMember = "DisplayName";
                   drp_entities.ValueMember = "EntityId";
                    
                   //Set business unit drop down
                   drp_BU.DataSource = null;
                   drp_BU.Items.Clear();
                   List<MyBusinessUnit> MyBus = Helper.getBUs();
                   MyBus.Sort((p, q) => p.DisplayName.CompareTo(q.DisplayName));
                   MyBusinessUnit Selectbu = new MyBusinessUnit();
                   Selectbu.DisplayName = "--Select--";
                   Selectbu.BuID = Guid.Empty;
                   MyBus.Insert(0, Selectbu);
                   drp_BU.DataSource = MyBus;
                   drp_BU.DisplayMember = "DisplayName";
                   drp_BU.ValueMember = "BuID";

                   //Set security role list
                   lstview_sRole.DataSource = null;
                   List<SecurityRole> userRoles = Helper.getSecurityRole();
                   Helper.SecurityRoles = userRoles;
                   lstview_sRole.DataSource = Helper.SecurityRoles;
                   lstview_sRole.DisplayMember = "Name";
                   lstview_sRole.ValueMember = "RoldId";
                   //Clear lstbox_users
                   lstbox_users.DataSource = null;
                   //Clear lstbox_Teams
                   lstbox_Teams.DataSource = null;
               },
               PostWorkCallBack = m =>
               {
                   if (m.Error == null)
                   {

                   }
                   else
                   {
                       MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                       MessageBoxIcon.Error);
                   }
               }
           });
            }
           



        }
        private void drp_entities_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool flag = this.drp_entities.SelectedIndex > 0;
            if (flag)
            {
                WorkAsync(new WorkAsyncInfo
         {
             Message = "Retrieveing security roles for " + ((MyEntity)drp_entities.SelectedItem).DisplayName + " ,it may take more time.",
             Work = (bw, m) =>
             {
                 if (grdview_user.InvokeRequired)
                 {
                     grdview_user.Invoke(new Action(() =>
                     {
                         grdview_user.DataSource = null;
                     }));
                 }
                 else
                 grdview_user.DataSource = null;

                 MyEntity entity = (MyEntity)drp_entities.SelectedItem;
                 Helper.RolePrivileges(entity);
                 if (grdview_user.InvokeRequired)
                 {
                     grdview_user.Invoke(new Action(() =>
                     {
                         grdview_user.DataSource = Helper.Privilage;
                     }));
                 }
                 else
                 grdview_user.DataSource = Helper.Privilage;
                 
             },
             PostWorkCallBack = m =>
             {
                 if (m.Error == null)
                 {

                 }
                 else
                 {
                     MessageBox.Show(this, "An error occured: " + m.Error.Message, "Error", MessageBoxButtons.OK,
                                     MessageBoxIcon.Error);
                 }
             }
         });
            }


        }
      
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox1.Text))
                grdview_user.DataSource = Helper.Privilage.Where(x => x.RoleName.ToLower().Contains(textBox1.Text.ToLower())).ToList();
            else
                grdview_user.DataSource = Helper.Privilage;
        }

        private void lstview_sRole_SelectedIndexChanged(object sender, EventArgs e)
        {
            bool flag = this.lstview_sRole.SelectedIndex > 0;
            bool flag2 = this.drp_BU.SelectedIndex > 0;
           
            if (flag && flag2)
            {
                SecurityRole SecurityRole = (SecurityRole)lstview_sRole.SelectedItem;
                List<Team> userTeams = Helper.getTeambySecurityRole(SecurityRole.Name, ((MyBusinessUnit)(drp_BU.SelectedItem)).DisplayName);
                Helper.Teams = userTeams;
                lstbox_Teams.DataSource = Helper.Teams;
                lstbox_Teams.DisplayMember = "Name";
                lstbox_Teams.ValueMember = "TeamId";

                List<systemUser> SystemUsers = Helper.getUserbySecurityRole(SecurityRole.Name, ((MyBusinessUnit)(drp_BU.SelectedItem)).DisplayName);
                Helper.SystemUser = SystemUsers;
                lstbox_users.DataSource = Helper.SystemUser;
                lstbox_users.DisplayMember = "FullName";
                lstbox_users.ValueMember = "SystemUserID";


            }
        }

        private void drp_BU_SelectedIndexChanged(object sender, EventArgs e)
        {
            lstview_sRole_SelectedIndexChanged(sender, e);
        }

        private void btn_Close_Click(object sender, EventArgs e)
        {
            base.CloseTool();
        }

        private void btn_Export_Click(object sender, EventArgs e)
        {
            if (grdview_user.Rows.Count > 1)
            {
                Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
                // creating new WorkBook within Excel application  
                Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
                // creating new Excelsheet in workbook  
                Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
                // see the excel sheet behind the program  
                app.Visible = true;
                // get the reference of first sheet. By default its name is Sheet1.  
                // store its reference to worksheet  
                worksheet = workbook.Sheets["Sheet1"];
                worksheet = workbook.ActiveSheet;
                // changing the name of active sheet  
                worksheet.Name = ((MyEntity)drp_entities.SelectedItem).DisplayName;
                // storing header part in Excel  
                for (int i = 1; i < grdview_user.Columns.Count + 1; i++)
                {
                    worksheet.Cells[1, i] = grdview_user.Columns[i - 1].HeaderText;

                }
                //Header Style
                Microsoft.Office.Interop.Excel.Style HeaderStyle = workbook.Styles.Add("HeaderStyle");
                HeaderStyle.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                HeaderStyle.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Green);
                Microsoft.Office.Interop.Excel.Range HrangeStyles = app.get_Range("A1", "I1");
                HrangeStyles.Style = "HeaderStyle";
                //Cell Style
                Microsoft.Office.Interop.Excel.Style CellStyle = workbook.Styles.Add("CellStyle");
                CellStyle.Font.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.White);
                CellStyle.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.DimGray);
                Microsoft.Office.Interop.Excel.Range CrangeStyles = app.get_Range("A2", "A" + (grdview_user.Rows.Count));
                CrangeStyles.Style = "CellStyle";

                // storing Each row and column value to excel sheet  
                for (int i = 0; i < grdview_user.Rows.Count - 1; i++)
                {
                    for (int j = 0; j < grdview_user.Columns.Count; j++)
                    {
                        if (grdview_user.Rows[i].Cells[j].ValueType.Name.ToString() == "String")
                        {
                            worksheet.Cells[i + 2, j + 1] = grdview_user.Rows[i].Cells[j].Value.ToString();
                        }
                        else
                        {
                            if (((Image)grdview_user.Rows[i].Cells[j].Value).Tag != null)
                                worksheet.Cells[i + 2, j + 1] = ((Image)grdview_user.Rows[i].Cells[j].Value).Tag.ToString();
                        }

                    }
                }
                worksheet.Columns.AutoFit();
                // save the application 
                workbook.SaveAs(saveExcel(), Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing);
                // Exit from the application  
                app.Quit();
            }
        }

        internal object saveExcel()
        {

            SaveFileDialog sfd = new SaveFileDialog();// Create save the CSV
            sfd.Filter = "*.xls|*.xlsx";// filters for excel files only
            sfd.DefaultExt = "xlsx";
            sfd.AddExtension = true;
            sfd.FileName = "Entity Security Role.xlsx";
            sfd.Title = "Save Excel File";
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                return sfd.FileName;
            }
            else
            {
                return null;
            }
        }


    }
}
